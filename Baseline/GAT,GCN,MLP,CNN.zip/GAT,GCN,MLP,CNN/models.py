import torch
import torch.nn as nn
import torch.nn.functional as F
from layers import GraphAttentionLayer,GraphAttentionLayer_s,GMGAT_LAYER,GraphAttentionLayer_nosoft


class Baseline(nn.Module):
    def __init__(self, dim_in, dim_out, dropout, alpha, node_num, Type):
        super(Baseline, self).__init__()

        if Type == 'CNN':
            self.model = CNN_Baseline(dim_in,dim_out,dropout=dropout,alpha=alpha,node_num = node_num)
        elif Type == 'GCN':
            self.model = GCN_Baseline(dim_in,dim_out,dropout=dropout,alpha=alpha,node_num = node_num)
        elif Type == 'MLP':
            self.model = MLP_Baseline(dim_in,dim_out,dropout=dropout,alpha=alpha,node_num = node_num)
        else:
            self.model = GAT_Baseline(dim_in,dim_out,dropout=dropout,alpha=alpha,node_num = node_num)


    def forward(self, x, adj):
        y = self.model(x, adj)
        return  y


class GAT_Baseline(nn.Module):
    def __init__(self, dim_in, dim_out, dropout, alpha, node_num):
        """Dense version of GAT."""
        super(GAT_Baseline, self).__init__()
        self.node_num = node_num
        self.dim_out = dim_out
        self.fc = nn.Linear(dim_in,dim_in)
        self.attentionlayer = GraphAttentionLayer(dim_in, node_num, dropout=dropout, alpha=alpha, node_num=node_num,concat=True)
        self.outputlayer = GraphAttentionLayer(node_num, dim_out, dropout=dropout, alpha=alpha, node_num=node_num, concat=True)

        self.fc1 = nn.Linear(node_num*dim_out, node_num)
        self.fc2 = nn.Linear(node_num, dim_out)

        self.dropout = nn.Dropout(dropout)
        self.leakyrelu = nn.LeakyReLU(alpha)
        self.bn = nn.BatchNorm1d(12)
    def forward(self, x, adj):

        x = F.relu(self.fc(x))
        x = self.attentionlayer(x, adj)
        x = self.dropout(x)
        x = self.outputlayer(x, adj)
        x = self.dropout(x)

        x = torch.reshape(x, (-1, self.node_num*self.dim_out))
        x = F.relu(self.fc1(x))
        x = self.dropout(x)
        x = self.fc2(x)
        y = self.dropout(x)

        return  y

class GCN_Baseline(nn.Module):
    def __init__(self, dim_in, dim_out, dropout, alpha, node_num):
        """Dense version of GAT."""
        super(GCN_Baseline, self).__init__()
        self.node_num = node_num
        self.dim_out = dim_out

        self.fc_1 = nn.Linear(dim_in ,node_num,bias=False)
        self.fc_2 = nn.Linear(node_num,dim_out,bias=False)

        self.fc1 = nn.Linear(node_num*dim_out, node_num)
        self.fc2 = nn.Linear(node_num, dim_out)

        self.dropout = nn.Dropout(dropout)
        self.leakyrelu = nn.LeakyReLU(alpha)
        self.bn = nn.BatchNorm1d(12)
    def forward(self, x, adj):
        A = normalize(adj,True).cuda()
        x = F.relu(self.fc_1(A.matmul(x)))
        x = F.relu(self.fc_2(A.matmul(x)))

        x = torch.reshape(x, (-1, self.node_num*self.dim_out))
        x = F.relu(self.fc1(x))
        x = self.dropout(x)
        x = self.fc2(x)
        y = self.dropout(x)

        return  y

class MLP_Baseline(nn.Module):
    def __init__(self, dim_in, dim_out, dropout, alpha, node_num):
        """Dense version of GAT."""
        super(MLP_Baseline, self).__init__()
        self.node_num = node_num
        self.fc1 = nn.Linear(dim_in, dim_in)
        self.fc2 = nn.Linear(dim_in, dim_in)
        self.fc3 = nn.Linear(dim_in, dim_in)
        self.fc4 = nn.Linear(dim_in*node_num, dim_out*node_num)
        self.fc5 = nn.Linear(dim_out*node_num, dim_out)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x, adj):
        x = F.relu(self.fc1(x))
        x = self.dropout(x)
        x = F.relu(self.fc2(x))
        x = self.dropout(x)
        x = F.relu(self.fc3(x))
        x = self.dropout(x)

        x = torch.reshape(x, (x.shape[0],-1))

        x = F.relu(self.fc4(x))
        x = self.dropout(x)

        y = self.fc5(x)
        return  y

class CNN_Baseline(nn.Module):
    def __init__(self, dim_in, dim_out, dropout, alpha, node_num):
        super(CNN_Baseline, self).__init__()

        self.fc1 = nn.Linear(dim_in, node_num)
        self.cov1 = nn.Conv2d(1, node_num, 1)
        self.cov2 = nn.Conv2d(node_num, node_num, node_num)
        self.fc2 = nn.Linear(node_num, node_num)
        self.fc3 = nn.Linear(node_num, dim_out)

        self.dropout = nn.Dropout(dropout)
    def forward(self, x, adj):
        x = x.unsqueeze(1)
        x = F.relu(self.fc1(x))
        x = self.dropout(x)

        x = F.relu(self.cov1(x))
        x = self.dropout(x)
        x = F.relu(self.cov2(x))
        x = self.dropout(x)
        x = x.squeeze()

        x = F.relu(self.fc2(x))
        x = self.dropout(x)
        y = self.fc3(x)

        return  y


def normalize(A , symmetric=True):
    A = torch.FloatTensor(A)
    A = A + torch.eye(A.size(1))
    # 所有节点的度
    d = A.sum(2)
    if symmetric:
        #D = D^-1/2
        D = torch.pow(d, -0.5)
        D = torch.diag_embed(D)
        return D.matmul(A).matmul(D)
    else :
        # D=D^-1
        D =torch.diag(torch.pow(d,-1))
        return D.matmul(A)


