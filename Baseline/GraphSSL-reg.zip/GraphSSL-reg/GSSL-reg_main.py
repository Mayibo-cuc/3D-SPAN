import torch
#from torch_geometric.datasets import TUDataset
#from torch_geometric.data import DataLoader
from torch_geometric import utils
import torch.nn.functional as F
import argparse
import os
from torch.utils.data import random_split
from LoadData import MyDataset,accuracy,accuracy_new,accuracy_F1,MyDataset_new
from torch.utils.data import DataLoader
import scipy.sparse as sp
import numpy as np
from torch_geometric.data import Data
from torch_geometric.data.batch import Batch

import moco.builder
from augmentation import random_augmentation
from HGP_SL.models import Model_joint
from torch.autograd import Variable
import json

parser = argparse.ArgumentParser()
parser.add_argument('--epochs', default=1000, type=int, metavar='N',help='number of total epochs to run')
parser.add_argument('-j', '--workers', default=0, type=int, metavar='N',help='number of data loading workers ')
parser.add_argument('--start-epoch', default=0, type=int, metavar='N',help='manual epoch number (useful on restarts)')
parser.add_argument('-b', '--batch-size', default=150, type=int,metavar='N',help='mini-batch size (default: 16)')
parser.add_argument('--lr', '--learning-rate', default=0.0001, type=float,metavar='LR', help='initial learning rate', dest='lr')
parser.add_argument('--schedule', default=[100,1000], nargs='*', type=int,help='learning rate schedule (when to drop lr by 10x)')
parser.add_argument('--momentum', default=0.9, type=float, metavar='M',help='momentum of SGD solver')
parser.add_argument('--wd', '--weight-decay', default=1e-4, type=float,metavar='W', help='weight decay (default: 1e-4)',dest='weight_decay')
parser.add_argument('-p', '--print-freq', default=10, type=int,metavar='N', help='print frequency (default: 10)')
parser.add_argument('--resume', default='', type=str, metavar='PATH',help='path to latest checkpoint (default: none)')
parser.add_argument('--seed', default=777, type=int,help='seed for initializing training. ')
parser.add_argument('--gpu', default=None, type=int,help='GPU id to use.')

# moco specific configs:
parser.add_argument('--moco-dim', default=128, type=int,help='feature dimension (default: 128)')
parser.add_argument('--moco-k', default=3000, type=int,help='queue size; number of negative keys (default: 2048)')
parser.add_argument('--moco-m', default=0.999, type=float,help='moco momentum of updating key encoder (default: 0.999)')
parser.add_argument('--moco-t', default=0.07, type=float,help='softmax temperature (default: 0.07)')

parser.add_argument('--cos', action='store_true',help='use cosine lr schedule')

# HGP-SL configs:
parser.add_argument('--sample_neighbor', type=bool, default=False, help='whether sample neighbors')
parser.add_argument('--sparse_attention', type=bool, default=True, help='whether use sparse attention')
parser.add_argument('--structure_learning', type=bool, default=True, help='whether perform structure learning')
parser.add_argument('--pooling_ratio', type=float, default=0.5, help='pooling ratio')
parser.add_argument('--dropout_ratio', type=float, default=0.0, help='dropout ratio')
parser.add_argument('--lamb', type=float, default=1.0, help='trade-off parameter')
parser.add_argument('--dataset', type=str, default='NCI1', help='DD/PROTEINS/NCI1/NCI109/Mutagenicity/all')
parser.add_argument('--patience', type=int, default=100, help='early stopping')

args = parser.parse_args()
args.device = 'cpu'
torch.manual_seed(args.seed)
if torch.cuda.is_available():
    torch.cuda.manual_seed(args.seed)
    args.device = 'cuda:0'

# 提取数据集
Room_type = 'All_Room'
args.num_classes = 2
args.num_features = 33
args.nhid = args.moco_dim

train_data = MyDataset_new(dataset=os.getcwd() + '/data/' + Room_type + '_train.json')
val_data = MyDataset_new(dataset=os.getcwd() + '/data/' + Room_type + '_val.json')
test_data = MyDataset_new(dataset=os.getcwd() + '/data/' + Room_type + '_test.json')
'''
def Dataset2datalist(dataset):
    datalist = []
    for i in range(len(dataset)):
        zero = dataset.zero_nodes[i][0]
        feature = torch.FloatTensor(np.array(dataset.features[i]))
        adj = torch.FloatTensor(np.array(dataset.adjs[i]))
        scene_label = torch.LongTensor(np.array(dataset.scene_labels[i]))
        if zero < 1:
            x = feature
        else:
            x = feature[:-(zero)]
        ed = sp.coo_matrix(adj)
        indices = np.vstack((ed.row, ed.col))
        edge = torch.LongTensor(indices)
        label = scene_label

        data = Data(x=x, edge_index=edge, y=label, edge_attr=None)
        datalist.append(data)
    return datalist

training_set = Dataset2datalist(train_data)
validation_set = Dataset2datalist(val_data)
test_set = Dataset2datalist(test_data)
'''

train_loader = DataLoader(dataset=train_data, batch_size=args.batch_size, shuffle=True, num_workers=0, pin_memory=True)
val_loader = DataLoader(dataset=val_data, batch_size=args.batch_size, shuffle=False, num_workers=0, pin_memory=True)
test_loader = DataLoader(dataset=test_data, batch_size=1, shuffle=False, num_workers=0, pin_memory=True)

HGP_SL = Model_joint(args)
model = moco.builder.MoCo(HGP_SL,args.moco_dim, args.moco_k, args.moco_m, args.moco_t).cuda()
optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
criterion = torch.nn.CrossEntropyLoss().cuda()


def val(model,loader):
    model.eval()
    correct = 0.
    loss_all = 0.
    for i, (features, adjs, gmms, evaluates,scene_labels,zero_nodes,zero_masks,scene_name) in enumerate(loader):
        data_batch = []
        for j in range(len(features)):
            zero = zero_nodes[j]-5
            if zero < 1:
                x = features[j]
            else:
                x = features[j, :-(zero)]
            ed = sp.coo_matrix(adjs[j])
            indices = np.vstack((ed.row, ed.col))
            edge = torch.LongTensor(indices)
            label = scene_labels[j]

            x = Variable(x, requires_grad=True)

            data = Data(x=x, edge_index=edge, y=label, edge_attr=None)
            data_batch.append(data)

        data1 = Batch.from_data_list(data_batch).to(args.device)
        data2 = Batch.from_data_list(random_augmentation(data_batch)).to(args.device)
        data3 = Batch.from_data_list(random_augmentation(data_batch)).to(args.device)

        output, target, q_cls = model(im_q=data2, im_k=data3, image=data1)
        loss = criterion(output.cuda(), target.cuda())
        loss_cls = F.nll_loss(q_cls, data1.y).cuda()
        loss = 0.001 * loss + loss_cls

        pred = q_cls.max(dim=1)[1]
        correct += pred.eq(data1.y).sum().item()
        loss_all += loss.item()
    return correct / len(loader.dataset),loss_all / len(loader.dataset)

def test(model,loader):
    savedata = []
    model.eval()
    cor_all = np.zeros(args.num_classes).tolist()
    num_all = np.zeros(args.num_classes).tolist()
    for i, (features, adjs, gmms, evaluates,scene_labels,zero_nodes,zero_masks,scene_name) in enumerate(loader):
        data_batch = []
        for j in range(len(features)):
            zero = zero_nodes[j] - 5
            if zero < 1:
                x = features[j]
            else:
                x = features[j, :-(zero)]
            ed = sp.coo_matrix(adjs[j])
            indices = np.vstack((ed.row, ed.col))
            edge = torch.LongTensor(indices)
            label = scene_labels[j]

            x = Variable(x, requires_grad=True)

            data = Data(x=x, edge_index=edge, y=label, edge_attr=None)
            data_batch.append(data)

        data1 = Batch.from_data_list(data_batch).to(args.device)
        data2 = Batch.from_data_list(random_augmentation(data_batch)).to(args.device)
        data3 = Batch.from_data_list(random_augmentation(data_batch)).to(args.device)

        output, target, q_cls = model(im_q=data2, im_k=data3, image=data1)

        a = torch.reshape(torch.argmax(q_cls, 1), (-1, 1)).item()
        savedata.append({'scene_name': scene_name[0], 'scene_score': a})

        cor,num = accuracy_F1(q_cls, data1.y, 0)
        cor_all += cor
        num_all += num
    all_acc = cor_all.sum()/num_all.sum()
    rc = cor_all/num_all
    recall = rc.sum() / args.num_classes
    F1 = 2 * recall * all_acc / (recall + all_acc)

    all_data = {}
    all_data['graph'] = savedata
    with open(os.getcwd() + '/GSSL-reg_test.json', 'w') as file_obj:
        json.dump(all_data, file_obj)
    file_obj.close()

    return all_acc,recall,F1


min_loss = 1e10
patience = 0

for epoch in range(args.epochs):
    model.train()
    for i, (features, adjs, gmms, evaluates,scene_labels,zero_nodes,zero_masks,scene_name) in enumerate(train_loader):
        data_batch = []
        for j in range(len(features)):
            zero = zero_nodes[j]-5
            if zero < 1:
                x = features[j]
            else:
                x = features[j, :-(zero)]
            ed = sp.coo_matrix(adjs[j])
            indices = np.vstack((ed.row, ed.col))
            edge = torch.LongTensor(indices)
            label = scene_labels[j]

            x = Variable(x,requires_grad=True)

            data = Data(x=x,edge_index=edge,y=label,edge_attr=None)
            data_batch.append(data)

        data1 = Batch.from_data_list(data_batch).to(args.device)
        data2 = Batch.from_data_list(random_augmentation(data_batch)).to(args.device)
        data3 = Batch.from_data_list(random_augmentation(data_batch)).to(args.device)


        output, target, q_cls = model(im_q=data2, im_k=data3,image = data1)
        loss = criterion(output.cuda(), target.cuda())
        loss_cls = F.nll_loss(q_cls, data1.y).cuda()
        loss = 0.001 * loss + loss_cls
        print("Training loss:{}".format(loss.item()))
        loss.backward()
        optimizer.step()
        optimizer.zero_grad()
    val_acc,val_loss = val(model,val_loader)
    print("Validation loss:{}\taccuracy:{}".format(val_loss,val_acc))
    if val_loss < min_loss:
        torch.save(model.state_dict(),'latest.pth')
        print("Model saved at epoch{}".format(epoch))
        min_loss = val_loss
        patience = 0
    else:
        patience += 1
    if patience > args.patience:
        break 

HGP_SL = Model_joint(args)
model = moco.builder.MoCo(HGP_SL,args.moco_dim, args.moco_k, args.moco_m, args.moco_t)
model.load_state_dict(torch.load('latest.pth'))
test_acc,test_recall,test_F1 = test(model,test_loader)
print("Test accuarcy:"+str(test_acc))
print("Test recall:"+str(test_recall))
print("Test f1:"+str(test_F1))
