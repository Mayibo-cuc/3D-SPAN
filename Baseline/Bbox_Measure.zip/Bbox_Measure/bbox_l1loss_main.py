import numpy as np
import scipy.sparse as sp
import torch
import os
import csv
import json
import math
import pickle
import random
from util import *

# 提取场景的全局边界框和标签
def Q_data(graph_q,mode):

    features = graph_q['feature']
    score = graph_q['scene_score']
    bbox_g = []
    for j in range(len(features)-graph_q['zero_num']):
        position = np.array(features[j][9:12])
        rotation = np.array(features[j][12:15])
        scale = np.array(features[j][15:18])
        maxpoint = np.array(features[j][3:6])
        minpoint = np.array(features[j][6:9])

        localbbox_max = np.multiply(maxpoint, scale)
        localbbox_min = np.multiply(minpoint, scale)
        localbbox_max, localbbox_min = Adjust_bbox(localbbox_max, localbbox_min, rotation)
        globbox_max = localbbox_max + position
        globbox_min = localbbox_min + position
        if mode == '3D':
            globbox = np.zeros((6))
            globbox[0:3] = globbox_max
            globbox[3:6] = globbox_min
        if mode == '2D':
            globbox = np.zeros((4))
            globbox[0] = globbox_max[0]
            globbox[1] = globbox_max[2]
            globbox[2] = globbox_min[0]
            globbox[3] = globbox_min[2]
        bbox_g.append(globbox.tolist())

    return bbox_g,score

# 计算边界框L1损失
def BBOX_caculate(bbox_q,bbox_t):
    bbox_L1 = np.zeros((len(bbox_t), len(bbox_q)))
    bbox_L1_min = np.zeros((len(bbox_t)))
    for i in range(len(bbox_t)):
        for j in range(len(bbox_q)):
            bbox_L1[i][j] = np.sum(np.abs(np.array(bbox_t[i]) - np.array(bbox_q[j])))

    for i in range(len(bbox_L1_min)):
        bbox_L1_min[i] = np.min(bbox_L1[i])

    loss = np.mean(bbox_L1_min)
    return loss

# 提取目标场景集和查询场景集，并遍历比较
def BBOX_L1(mode,output_mode = False):
    savedata = []
    num = [0,0] # bad good
    cor = [0,0] # bad good

    with open('./data/All_Room_train.json', 'r') as f:
        Train_data = json.load(f)  # 直接从json文件中读取数据返回一个python对象
    f.close()
    with open('./data/All_Room_val.json', 'r') as f:
        Val_data = json.load(f)  # 直接从json文件中读取数据返回一个python对象
    f.close()
    with open('./data/All_Room_test.json', 'r') as f:
        Test_data = json.load(f)  # 直接从json文件中读取数据返回一个python对象
    f.close()

    Train_graphs = Train_data['graph'] + Val_data['graph']
    Test_graphs = Test_data['graph']

    for i in range(len(Test_graphs)):
        Test_bbox,Test_label = Q_data(Test_graphs[i],mode)
        print(Test_graphs[i]['scene_name'])
        min_loss = 1000
        Predict_label = 0
        for j in range(len(Train_graphs)):
            Train_bbox, Train_label = Q_data(Train_graphs[j],mode)
            loss = BBOX_caculate(Train_bbox,Test_bbox)
            if loss < min_loss:
                min_loss = loss
                Predict_label = Train_label
        num[Test_label] += 1
        if  Predict_label == Test_label:
            cor[Test_label] += 1

        if output_mode:
            savedata.append({'scene_name': Test_graphs[i]['scene_name'],'scene_score': Predict_label})

    acc = (cor[0]+cor[1])/(num[0]+num[1])
    recall = ((cor[0]/num[0])+(cor[1]/num[1]))/2
    F1 = (acc + recall)/2

    print('acc:'+str(acc))
    print('recall:'+str(recall))
    print('F1:'+str(F1))

    if output_mode:
        all_data = {}
        all_data['graph'] = savedata

        with open(os.getcwd() + '/'+mode+'-box_test.json', 'w') as file_obj:
            json.dump(all_data, file_obj)
        file_obj.close()

if __name__=="__main__":
    mode = '2D' # 2D or 3D
    output_mode = True # whether output the test file
    BBOX_L1(mode,output_mode)