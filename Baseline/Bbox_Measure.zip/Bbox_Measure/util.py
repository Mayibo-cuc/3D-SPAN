'''
函数类
'''

import json
import numpy as np
import math
import csv
import os
import sympy


def mkdir(path):
    folder = os.path.exists(path)

    if not folder:  # 判断是否存在文件夹如果不存在则创建为文件夹
        os.makedirs(path)

def Get_attribute2( model_id):#根据模型ID（str）找到对应的模型属性

    with open("dataset/models.csv", "r", encoding = "utf-8") as f:
        reader = csv.DictReader(f)
        column = [row for row in reader]

    for index, item in enumerate(column):
        id = column[index].get('id')
        row = index
        if id == model_id:
            break

    maxPoint = column[row].get('maxPoint').strip(',').split(',')
    minPoint = column[row].get('minPoint').strip(',').split(',')
    front_dir = column[row].get('front').strip(',').split(',')

    for i in range(3):
        maxPoint[i] = float(maxPoint[i])
        minPoint[i] = float(minPoint[i])
        front_dir[i] = float(front_dir[i])

    return maxPoint,minPoint,front_dir#,front_dir_ob

def Get_attribute1( model_id):#根据模型ID（str）找到对应的模型属性
    with open("dataset/SUNCG_id2type.csv", "r", encoding = "utf-8") as f:
        reader = csv.DictReader(f)
        column = [row for row in reader]

    for index, item in enumerate(column):
        id = column[index].get('model_id')
        row = index
        if id == model_id:
            break

    object_name = column[row].get('fine_grained_class')
    object_class = column[row].get('coarse_grained_class')


    return object_name,object_class

def Rotation_caculate(front1,front2):
    dx1 = front1[0]
    dx2 = front2[0]
    dz1 = front1[2]
    dz2 = front2[2]
    angle1 = math.atan2(dz1,dx1)
    angle2 = math.atan2(dz2,dx2)
    angle1 = int(angle1 * 180 / math.pi)
    angle2 = int(angle2 * 180 / math.pi)
    angle = (angle1 - angle2)%360#因为SUNCG数据集中旋转机制与Unity中是相反的
    #限制在[0,360]
    while(angle <0):
        angle = angle+360
    return [0,angle,0]

#计算物体正前方角度（x为横正半轴(0°),z为纵正半轴(90°)）
def Front_caculate(node):
    front = np.array(node['model_front'])
    angle = math.atan2(front[2],front[0])
    angle = int(angle * 180 / math.pi)
    # 限制在[0,360]
    angle = (angle - node['rotation'][1])%360#因为Unity中旋转是顺时针，所以是减
    while(angle <0):
        angle = angle+360
    return angle

def Adjust_bbox(bbox_max,bbox_min,rotation):#根据旋转角度调整bbox
    bbox_max_new = []
    bbox_min_new = []
    v1 = np.asarray((bbox_max[0], bbox_max[2]))
    v2 = np.asarray((bbox_max[0], bbox_min[2]))
    v3 = np.asarray((bbox_min[0], bbox_max[2]))
    v4 = np.asarray((bbox_min[0], bbox_min[2]))
    angle = rotation[1] /180 * math.pi
    rotate_matrix = np.asarray([[math.cos(angle), -math.sin(angle)], [math.sin(angle), math.cos(angle)]])
    new_v1 = np.dot(v1, rotate_matrix)
    new_v2 = np.dot(v2, rotate_matrix)
    new_v3 = np.dot(v3, rotate_matrix)
    new_v4 = np.dot(v4, rotate_matrix)
    new_x = [new_v1[0],new_v2[0],new_v3[0],new_v4[0]]
    new_z = [new_v1[1], new_v2[1], new_v3[1], new_v4[1]]
    bbox_max_new.append(max(new_x))
    bbox_max_new.append(bbox_max[1])
    bbox_max_new.append(max(new_z))
    bbox_min_new.append(min(new_x))
    bbox_min_new.append(bbox_min[1])
    bbox_min_new.append(min(new_z))
    return np.array(bbox_max_new),np.array(bbox_min_new)

def judge_support(top_node,end_node):
    relation = None

    t_p = np.array(top_node['position'])
    e_p = np.array(end_node['position'])
    t_max = np.multiply(np.array(top_node['maxpoint']), np.array(top_node['scale']))
    t_min = np.multiply(np.array(top_node['minpoint']), np.array(top_node['scale']))
    e_max = np.multiply(np.array(end_node['maxpoint']), np.array(end_node['scale']))
    e_min = np.multiply(np.array(end_node['minpoint']), np.array(end_node['scale']))
    t_max,t_min = Adjust_bbox(t_max, t_min, top_node['rotation'])
    e_max,e_min = Adjust_bbox(e_max, e_min, end_node['rotation'])
    top_x_max = t_max[0] + t_p[0]
    top_x_min = t_min[0] + t_p[0]
    top_y_max = t_max[1] + t_p[1]
    top_y_min = t_min[1] + t_p[1]
    top_z_max = t_max[2] + t_p[2]
    top_z_min = t_min[2] + t_p[2]
    end_x_max = e_max[0] + e_p[0]
    end_x_min = e_min[0] + e_p[0]
    end_y_max = e_max[1] + e_p[1]
    end_y_min = e_min[1] + e_p[1]
    end_z_max = e_max[2] + e_p[2]
    end_z_min = e_min[2] + e_p[2]

    #判断是否是支撑关系
    if((abs(top_x_max - end_x_max) + abs(top_x_min - end_x_min)) <(abs(top_x_max - top_x_min) + abs(end_x_max - end_x_min))
    and (abs(top_z_max - end_z_max) + abs(top_z_min - end_z_min)) <(abs(top_z_max - top_z_min) + abs(end_z_max - end_z_min))
    and abs(end_y_min - top_y_max) < 0.03):
        relation = 'support'

    #判断是否是被支撑关系
    elif((abs(top_x_max - end_x_max) + abs(top_x_min - end_x_min)) <(abs(top_x_max - top_x_min) + abs(end_x_max - end_x_min))
    and (abs(top_z_max - end_z_max) + abs(top_z_min - end_z_min)) <(abs(top_z_max - top_z_min) + abs(end_z_max - end_z_min))
    and abs(end_y_max - top_y_min) < 0.03):
        relation = 'supported-by'

    return relation

def judge_coplane(top_node,end_node,RoomType):
    relation = None
    isgroup = False
    top_ground = False
    end_ground = False

    for each in group[RoomType]:
        if (top_node['object_name'] == each[0] and end_node['object_name'] == each[1]) or (end_node['object_name'] == each[0] and top_node['object_name'] == each[1]):
            isgroup = True

    t_p = np.array(top_node['position'])
    e_p = np.array(end_node['position'])
    t_max = np.multiply(np.array(top_node['maxpoint']), np.array(top_node['scale']))
    t_min = np.multiply(np.array(top_node['minpoint']), np.array(top_node['scale']))
    e_max = np.multiply(np.array(end_node['maxpoint']), np.array(end_node['scale']))
    e_min = np.multiply(np.array(end_node['minpoint']), np.array(end_node['scale']))
    t_max,t_min = Adjust_bbox(t_max, t_min, top_node['rotation'])
    e_max,e_min = Adjust_bbox(e_max, e_min, end_node['rotation'])
    top_x_max = t_max[0] + t_p[0]
    top_x_min = t_min[0] + t_p[0]
    top_y_max = t_max[1] + t_p[1]
    top_y_min = t_min[1] + t_p[1]
    top_z_max = t_max[2] + t_p[2]
    top_z_min = t_min[2] + t_p[2]
    end_x_max = e_max[0] + e_p[0]
    end_x_min = e_min[0] + e_p[0]
    end_y_max = e_max[1] + e_p[1]
    end_y_min = e_min[1] + e_p[1]
    end_z_max = e_max[2] + e_p[2]
    end_z_min = e_min[2] + e_p[2]

    #判断是否是共面关系
    if ((abs(top_x_max - end_x_max) + abs(top_x_min - end_x_min) - abs(top_x_max - top_x_min) - abs(end_x_max - end_x_min)> -0.05
    or abs(top_z_max - end_z_max) + abs(top_z_min - end_z_min) - abs(top_z_max - top_z_min) - abs(end_z_max - end_z_min)> -0.05)
    and abs(end_y_min - top_y_min) < 0.03 and top_node['object_name'] != 'wall' and end_node['object_name'] != 'wall'):
        relation = 'coplane'

    #判断是否是组关系
    if (((abs(top_x_max - end_x_max) + abs(top_x_min - end_x_min)) <= 1.5*(abs(top_x_max - top_x_min) + abs(end_x_max - end_x_min))
         and (abs(top_z_max - end_z_max) + abs(top_z_min - end_z_min)) <= 1.5*(abs(top_z_max - top_z_min) + abs(end_z_max - end_z_min)))
         and abs(end_y_min - top_y_min) < 0.03 and isgroup):
        relation = 'combine'

    if(abs(top_y_min) < 0.03):top_ground = True
    if(abs(end_y_min) < 0.03):end_ground = True

    return relation,top_ground,end_ground

def judge_near(top_node,end_node):
    relation = None

    top_front = Front_caculate(top_node)
    end_front = Front_caculate(end_node)

    #先计算前向夹角(尾节点相较头结点旋转了多少,逆时针为负，顺时针为正,值域为[-180,180])
    direction_rotation = top_front - end_front
    if(direction_rotation<-180):
        direction_rotation = 360 + direction_rotation
    if(direction_rotation>180):
        direction_rotation = direction_rotation - 360

    #判断是否是靠墙关系
    if(top_node['object_name'] != 'wall' and end_node['object_name'] == 'wall'):
        if direction_rotation < 45 and direction_rotation > -45:
            relation = 'back_near'
        elif direction_rotation <= 135 and direction_rotation >= 45:
            relation = 'left_near'
        elif direction_rotation <= -45 and direction_rotation >= -135:
            relation = 'right_near'
        else:
            relation = 'front_near'

    return relation

def Extract_graph(room,RoomType):
    top_nodes = []
    edges = []
    end_nodes = []

    # 判断关系，存储边(支撑、被支撑)
    for i in range(len(room)):
        top_node = room[i]
        for j in range(len(room)):
            end_node = room[j]
            if (i == j):
                continue
            else:
                edge = judge_support(top_node, end_node)
                if (edge != None):
                    top_nodes.append(top_node['id'])
                    end_nodes.append(end_node['id'])
                    edges.append(edge)

    # 判断关系，存储边(组关系、共面)
    for i in range(len(room)):
        top_node = room[i]
        for j in range(len(room)):
            end_node = room[j]
            if (i == j):
                continue
            else:
                edge, top_supported, end_supported = judge_coplane(top_node, end_node,RoomType)
                for k in range(len(edges)):  # 防止悬空
                    if edges[k] == 'supported-by' and top_nodes[k] == top_node['id']:
                        top_supported = True
                    if edges[k] == 'supported-by' and top_nodes[k] == end_node['id']:
                        end_supported = True
                if (edge != None and top_supported and end_supported):
                    top_nodes.append(top_node['id'])
                    end_nodes.append(end_node['id'])
                    edges.append(edge)

    # 判断关系，存储边(墙)
    for i in range(len(room)):
        top_node = room[i]
        for j in range(len(room)):
            end_node = room[j]
            if (i == j):
                continue
            else:
                Can_near = False
                edge = judge_near(top_node, end_node)
                for k in range(len(edges)):  # 有关系的物体才建立墙关系
                    if top_nodes[k] == top_node['id']:
                        Can_near = True
                if (edge != None and Can_near):
                    top_nodes.append(top_node['id'])
                    end_nodes.append(end_node['id'])
                    edges.append(edge)

    # 遍历关系，补充next关系
    for i in range(len(edges)):
        # 如果有组关系的头结点支撑其它物体，则将该物体与尾节点建立组关系
        if edges[i] == 'combine':
            for j in range(len(top_nodes)):
                if (top_nodes[i] == top_nodes[j]) and edges[j] == 'support':
                    isSave = True
                    for k in range(len(top_nodes)):
                        if (top_nodes[k] == end_nodes[i] and end_nodes[k] == end_nodes[j] and edges[k] == 'next'):
                            isSave = False
                    if isSave:
                        top_nodes.append(end_nodes[i])
                        end_nodes.append(end_nodes[j])
                        edges.append('next')
                        top_nodes.append(end_nodes[j])
                        end_nodes.append(end_nodes[i])
                        edges.append('next')
    return top_nodes,edges,end_nodes

def get_bbox_dict():

    bbox_dict = {}
    f = open("dataset/bbox调整.txt")
    line = f.readline()
    while line:
        new_line = line.split('_')
        if new_line[0] == 's':
            key = 's__' + new_line[2]
            value = new_line[3] + ',' + new_line[4]
            bbox_dict.update({key: value})
        else:
            key = new_line[0]
            value = new_line[1] + ',' + new_line[2]
            bbox_dict.update({key: value})
        line = f.readline()
    f.close()
    return bbox_dict

def get_limit_object():
    limit_objects = {}
    limit_objects['Office'] = ['desk','office_chair','computer','shelving','chair', 'books','plant','armchair', 'picture_frame',
                               'laptop', 'sofa', 'wardrobe_cabinet','workplace', 'table_lamp','wall_lamp','floor_lamp']
    limit_objects['Living_Room'] = ['sofa','coffee_table','chair','plant','television','armchair','tv_stand','vase','books','refrigerator',
                                    'shelving','floor_lamp','ottoman','wall_lamp','cup','stereo_set','glass','fish_tank','bottle',
                                    'fruit_bowl','piano','stand','xbox','chessboard','hanger','clock']
    limit_objects['Bathroom'] = ['sink', 'toilet', 'bathtub', 'shower', 'shelving', 'towel_rack', 'mirror', 'washer',
                                 'plant', 'rug', 'wall_lamp']
    limit_objects['Bedroom'] = ['double_bed', 'single_bed', 'bunker_bed', 'wardrobe_cabinet', 'stand', 'sofa', 'dresser',
                    'floor_lamp', 'desk','dressing_table', 'coffee_table', 'armchair', 'office_chair', 'ottoman', 'chair', 'table_lamp',
                    'plant', 'laptop','books', 'computer', 'television', 'tv_stand']
    return limit_objects

def get_group():
    groups = {}
    groups['Bathroom'] = []
    groups['Bedroom'] = [
['desk', 'armchair'], ['desk', 'office_chair'],['desk', 'chair'],['desk', 'ottoman'],['desk', 'sofa'],
['dressing_table', 'armchair'], ['dressing_table', 'office_chair'],['dressing_table', 'chair'],['dressing_table', 'ottoman'],['dressing_table', 'sofa'],
['coffee_table', 'armchair'], ['coffee_table', 'office_chair'],['coffee_table', 'chair'],['coffee_table', 'ottoman'],['coffee_table', 'sofa'],['coffee_table', 'tv_stand'],
['double_bed', 'stand'],['double_bed','wardrobe_cabinet'],['double_bed','dresser'],['double_bed','floor_lamp'],
['single_bed', 'stand'],['single_bed','wardrobe_cabinet'],['single_bed','dresser'],['bed','floor_lamp'],
['bunker_bed', 'stand'],['bunker_bed','wardrobe_cabinet'],['bunker_bed','dresser'],['bunker_bed','floor_lamp']
]
    return groups

#限制类和禁用模型（选取的是高频模型）
limit_objects = get_limit_object()

ban_model = ['187','269','387','388','391','399','s__391','s__571','s__848','s__850','s__851','s__861','s__862','s__934',
's__935','s__936','s__938','s__939','s__940','s__941','s__942','s__943','s__1206','s__1207','s__1220','s__1221','s__1252',
's__1726','s__1727','s__1730','s__1735','s__1737','s__2240','s__2241','s__2351','s__2354','s__2404','s__2447','s__2451',
'195','197','312','483','534','s__539','s__1000','s__1242','s__1683','s__2304','s__2428',
'63','157','167','168','690','700','s__361','s__362','s__363','s__364','s__365','s__366','s__367','s__368','s__369','s__371',
's__372','s__373','s__374','s__375','s__376','s__377','s__378','s__379','s__380','s__383','s__502','s__503','s__504','s__515',
's__527','s__528','s__543','s__549','s__598','s__638','s__642','s__652','s__656','s__1067','s__1097','s__1127','s__1171',
's__1286','s__1674','s__1760','s__2158','s__2166','s__2173','s__2411','s__2412',
'469','s__430','s__592','s__1002','s__1738','s__1951','s__1953','s__2058',
'273','294','417','430','477','485','486','494','s__388','s__392','s__469','s__475','s__482','s__489','s__552','s__593',
's__714','s__722','s__806','s__1022','s__1225','s__1367','s__1372','s__1377','s__1392','s__1393','s__1419','s__1422',
's__1461','s__1473','s__1474','s__1495','s__1496','s__1499','s__2153','s__2155','s__2238','s__2245',
'199','s__1244','s__2045',
'172','565','569','579','586','591','s__554','s__595','s__1135','s__1720','s__1952','s__1989','s__2350']

#组关系
group = get_group()

# 读取更换的bbox
bbox_dict = get_bbox_dict()


