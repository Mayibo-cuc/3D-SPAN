import numpy as np
import scipy.sparse as sp
import torch
import os
import csv
import json
import math
import pickle
import random
from torch.utils.data import Dataset

def accuracy(output, labels, zero_num):
    preds = output.max(1)[1].type_as(labels)
    correct = preds.eq(labels).double()
    correct = correct.sum()
    all_acc = correct / len(labels)
    # all_acc = (correct - zero_num) / (len(labels) - zero_num)
    return all_acc

def accuracy_out(output, labels, zero_num):
    preds = output.max(1)[1].type_as(labels)
    correct = preds.eq(labels).double()
    correct = correct.sum()
    if len(labels.size()) == 2:
        all_acc = correct / labels.shape[1]
    else:
        all_acc = correct
    # all_acc = (correct - zero_num) / (len(labels) - zero_num)
    return all_acc.item()

def accuracy_new(output, labels, zero_num):# 用于三分类的准确率和召回率计算
    preds = output.max(1)[1].type_as(labels)
    correct = preds.eq(labels).double()

    cor = np.zeros(output.shape[1])
    num = np.zeros(output.shape[1])
    for i in range(len(labels)):
        num[labels[i]] = num[labels[i]]+1
        if correct[i] == 1:
            cor[labels[i]] = cor[labels[i]] + 1

    # 计算要减去墙
    cor[0] = cor[0] - zero_num
    num[0] = num[0] - zero_num
    acc = cor/num
    all_acc = (correct.sum() - zero_num) / (len(labels) - zero_num)
    recall = (acc[0] + acc[1]) / 2
    F1 = 2*recall*all_acc/(recall+all_acc)
    return all_acc,acc,num,F1

def accuracy_F1(output, labels, zero_num):# 用于三分类的准确率和召回率计算
    preds = output.max(1)[1].type_as(labels)
    correct = preds.eq(labels).double()

    cor = np.zeros(output.shape[1])
    num = np.zeros(output.shape[1])
    for i in range(len(labels)):
        num[labels[i]] = num[labels[i]]+1
        if correct[i] == 1:
            cor[labels[i]] = cor[labels[i]] + 1

    '''
    # 计算要减去无用节点
    cor[0] = cor[0] - zero_num
    num[0] = num[0] - zero_num
    '''

    return cor,num


def Extract_data(filepath):
    features = []
    adjs = []
    gmms = []
    evaluates = []
    scene_label = []
    zero_node = []
    zero_mask= []
    scene_names = []

    with open(filepath, 'r') as f:
        data = json.load(f)  # 直接从json文件中读取数据返回一个python对象
    f.close()
    graphs = data['graph']

    for i in range(len(graphs)):
        scene_names.append(graphs[i]['scene_name'])
        features.append(graphs[i]['feature'])
        adjs.append(graphs[i]['adj'])
        gmms.append(graphs[i]['gmm'])
        zero_node.append([graphs[i]['zero_num']])
        zero_mask.append([graphs[i]['zero_mask']])
        scene_score = graphs[i]['scene_score']

        scene_label.append([int(scene_score)])

        evaluate_content = graphs[i]['evaluate']

        evaluates.append(evaluate_content)

    return features,adjs,gmms,evaluates,scene_label,zero_node,zero_mask,scene_names


class MyDataset(Dataset):
    def __init__(self, dataset,transform=None,target_transform=None):
        super(MyDataset, self).__init__()

        features, adjs, gmms, evaluates,scene_labels,zero_node,zero_mask,scene_names = Extract_data(dataset)

        self.features = features
        self.adjs = adjs
        self.gmms = gmms
        self.evaluates = evaluates
        self.scene_labels = scene_labels
        self.zero_nodes = zero_node
        self.zero_masks = zero_mask

        self.transform = transform
        self.target_transform = target_transform

    def __getitem__(self, index):  # 这个方法是必须要有的，用于按照索引读取每个元素的具体内容
        feature = self.features[index]
        adj = self.adjs[index]
        gmm = self.gmms[index]
        evaluate = self.evaluates[index]
        scene_label = self.scene_labels[index]
        zero_nodes = self.zero_nodes[index]
        zero_masks = self.zero_masks[index]

        feature = torch.FloatTensor(np.array(feature))
        adj = torch.FloatTensor(np.array(adj))
        gmm = torch.FloatTensor(np.array(gmm))
        evaluate = torch.LongTensor(np.array(evaluate))
        scene_label = torch.LongTensor(np.array(scene_label))
        zero_nodes = np.array(zero_nodes)
        zero_masks = torch.FloatTensor(np.array(zero_masks))
        return feature, adj, gmm, evaluate,scene_label,zero_nodes,zero_masks

    def __len__(self):
            return len(self.features)


class MyDataset_new(Dataset):
    def __init__(self, dataset,transform=None,target_transform=None):
        super(MyDataset_new, self).__init__()

        features, adjs, gmms, evaluates,scene_labels,zero_node,zero_mask,scene_names = Extract_data(dataset)

        self.features = features
        self.adjs = adjs
        self.gmms = gmms
        self.evaluates = evaluates
        self.scene_labels = scene_labels
        self.zero_nodes = zero_node
        self.zero_masks = zero_mask
        self.scene_names = scene_names

        self.transform = transform
        self.target_transform = target_transform

    def __getitem__(self, index):  # 这个方法是必须要有的，用于按照索引读取每个元素的具体内容
        feature = self.features[index]
        adj = self.adjs[index]
        gmm = self.gmms[index]
        evaluate = self.evaluates[index]
        scene_label = self.scene_labels[index]
        zero_nodes = self.zero_nodes[index]
        zero_masks = self.zero_masks[index]
        scene_name = self.scene_names[index]

        feature = torch.FloatTensor(np.array(feature))
        adj = torch.FloatTensor(np.array(adj))
        gmm = torch.FloatTensor(np.array(gmm))
        evaluate = torch.LongTensor(np.array(evaluate))
        scene_label = torch.LongTensor(np.array(scene_label))
        zero_nodes = np.array(zero_nodes)
        zero_masks = torch.FloatTensor(np.array(zero_masks))
        return feature, adj, gmm, evaluate,scene_label,zero_nodes,zero_masks,scene_name

    def __len__(self):
            return len(self.features)
