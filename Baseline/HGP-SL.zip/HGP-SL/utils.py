import numpy as np
import scipy.sparse as sp
import torch
import os
import csv
import json
import math
import pickle
import random



def Extract_data(filepath):
    features = []
    gmms = []
    node_nums = []

    with open(filepath, 'r') as f:
        data = json.load(f)  # 直接从json文件中读取数据返回一个python对象
    f.close()
    graphs = data['graph']

    for i in range(len(graphs)):
        features.append(graphs[i]['feature'])
        gmms.append(graphs[i]['gmm'])
        node_nums.append(graphs[i]['node_num'])

    return features,gmms,node_nums



def load_data(dataset="bedroom_matrix.json"):#提取数据

    print('Loading {} ...'.format(dataset))
    filepath = os.getcwd() + '/data/' +dataset

    #读取json文件，按顺序提取features、gmms、evaluates
    features,gmms,node_nums = Extract_data(filepath)

    for i in range(len(features)):
        features[i] = torch.FloatTensor(np.array(features[i]))
        gmms[i] = torch.FloatTensor(np.array(gmms[i]))
        node_nums[i] = int(node_nums[i])

    return features,gmms,node_nums




