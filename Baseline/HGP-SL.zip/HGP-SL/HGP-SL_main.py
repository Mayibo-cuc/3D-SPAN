import torch
#from torch_geometric.datasets import TUDataset
#from torch_geometric.data import DataLoader
from torch_geometric import utils
from models import Model
import torch.nn.functional as F
import argparse
import os
from torch.utils.data import random_split
parser = argparse.ArgumentParser()
from LoadData import MyDataset,accuracy,accuracy_new,accuracy_F1
from torch.utils.data import DataLoader
import scipy.sparse as sp
import numpy as np
from torch_geometric.data import Data
from torch_geometric.data.batch import Batch

parser.add_argument('--seed', type=int, default=777, help='random seed')
parser.add_argument('--batch_size', type=int, default=150, help='batch size')
parser.add_argument('--lr', type=float, default=0.001, help='learning rate')
parser.add_argument('--weight_decay', type=float, default=0.001, help='weight decay')
parser.add_argument('--nhid', type=int, default=128, help='hidden size')
parser.add_argument('--sample_neighbor', type=bool, default=True, help='whether sample neighbors')
parser.add_argument('--sparse_attention', type=bool, default=True, help='whether use sparse attention')
parser.add_argument('--structure_learning', type=bool, default=True, help='whether perform structure learning')
parser.add_argument('--pooling_ratio', type=float, default=0.5, help='pooling ratio')
parser.add_argument('--dropout_ratio', type=float, default=0.0, help='dropout ratio')
parser.add_argument('--lamb', type=float, default=1.0, help='trade-off parameter')
parser.add_argument('--dataset', type=str, default='PROTEINS', help='DD/PROTEINS/NCI1/NCI109/Mutagenicity/ENZYMES')
parser.add_argument('--device', type=str, default='cuda:0', help='specify cuda devices')
parser.add_argument('--epochs', type=int, default=1000, help='maximum number of epochs')
parser.add_argument('--patience', type=int, default=100, help='patience for early stopping')

args = parser.parse_args()
args.device = 'cpu'
torch.manual_seed(args.seed)
if torch.cuda.is_available():
    torch.cuda.manual_seed(args.seed)
    args.device = 'cuda:0'

# 提取数据集
Room_type = 'All_Room'
args.num_classes = 2
args.num_features = 33

train_data = MyDataset(dataset=os.getcwd() + '/data/' + Room_type + '_train.json')
val_data = MyDataset(dataset=os.getcwd() + '/data/' + Room_type + '_val.json')
test_data = MyDataset(dataset=os.getcwd() + '/data/' + Room_type + '_test.json')
train_loader = DataLoader(dataset=train_data, batch_size=args.batch_size, shuffle=True, num_workers=0, pin_memory=True)
val_loader = DataLoader(dataset=val_data, batch_size=args.batch_size, shuffle=False, num_workers=0, pin_memory=True)
test_loader = DataLoader(dataset=test_data, batch_size=1, shuffle=False, num_workers=0, pin_memory=True)

model = Model(args).to(args.device)
optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)

def val(model,loader):
    model.eval()
    correct = 0.
    loss = 0.
    for i, (features, adjs, gmms, evaluates,scene_labels,zero_nodes,zero_masks) in enumerate(loader):
        data_batch = []
        for j in range(len(features)):
            zero = zero_nodes[j]-5
            if zero < 1:
                x = features[j]
            else:
                x = features[j, :-(zero)]
            ed = sp.coo_matrix(adjs[j])
            indices = np.vstack((ed.row, ed.col))
            edge = torch.LongTensor(indices)
            label = scene_labels[j]

            data = Data(x=x,edge_index=edge,y=label)
            data_batch.append(data)

        data = Batch.from_data_list(data_batch)
        data = data.to(args.device)
        out = model(data)
        pred = out.max(dim=1)[1]
        correct += pred.eq(data.y).sum().item()
        loss += F.nll_loss(out,data.y,reduction='sum').item()
    return correct / len(loader.dataset),loss / len(loader.dataset)

def test(model,loader):
    model.eval()
    cor_all = np.zeros(args.num_classes).tolist()
    num_all = np.zeros(args.num_classes).tolist()
    for i, (features, adjs, gmms, evaluates,scene_labels,zero_nodes,zero_masks) in enumerate(loader):
        data_batch = []
        for j in range(len(features)):
            zero = zero_nodes[j]-5
            if zero < 1:
                x = features[j]
            else:
                x = features[j, :-(zero)]
            ed = sp.coo_matrix(adjs[j])
            indices = np.vstack((ed.row, ed.col))
            edge = torch.LongTensor(indices)
            label = scene_labels[j]

            data = Data(x=x,edge_index=edge,y=label)
            data_batch.append(data)

        data = Batch.from_data_list(data_batch)
        data = data.to(args.device)
        out = model(data)
        cor,num = accuracy_F1(out, data.y, 0)
        cor_all += cor
        num_all += num
    all_acc = cor_all.sum()/num_all.sum()
    rc = cor_all/num_all
    recall = rc.sum() / args.num_classes
    F1 = 2 * recall * all_acc / (recall + all_acc)
    return all_acc,recall,F1


min_loss = 1e10
patience = 0

for epoch in range(args.epochs):
    model.train()
    for i, (features, adjs, gmms, evaluates,scene_labels,zero_nodes,zero_masks) in enumerate(train_loader):
        data_batch = []
        for j in range(len(features)):
            zero = zero_nodes[j]-5
            if zero < 1:
                x = features[j]
            else:
                x = features[j, :-(zero)]
            ed = sp.coo_matrix(adjs[j])
            indices = np.vstack((ed.row, ed.col))
            edge = torch.LongTensor(indices)
            label = scene_labels[j]

            data = Data(x=x,edge_index=edge,y=label)
            data_batch.append(data)

        data = Batch.from_data_list(data_batch)
        data = data.to(args.device)
        out = model(data)
        loss = F.nll_loss(out, data.y)
        print("Training loss:{}".format(loss.item()))
        loss.backward()
        optimizer.step()
        optimizer.zero_grad()
    val_acc,val_loss = val(model,val_loader)
    print("Validation loss:{}\taccuracy:{}".format(val_loss,val_acc))
    if val_loss < min_loss:
        torch.save(model.state_dict(),'latest.pth')
        print("Model saved at epoch{}".format(epoch))
        min_loss = val_loss
        patience = 0
    else:
        patience += 1
    if patience > args.patience:
        break 

model = Model(args).to(args.device)
model.load_state_dict(torch.load('latest.pth'))
test_acc,test_recall,test_F1 = test(model,test_loader)
print("Test accuarcy:"+str(test_acc))
print("Test recall:"+str(test_recall))
print("Test f1:"+str(test_F1))
